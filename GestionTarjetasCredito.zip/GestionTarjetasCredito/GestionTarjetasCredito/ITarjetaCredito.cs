﻿public interface ITarjetaCredito
{
    bool Bloqueada { get; set; }
    string NumeroTarjeta { get; set; }
    string PIN { get; set; }
    double Saldo { get; set; }

    void Dispose();
}