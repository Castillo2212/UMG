﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

public class TarjetaCredito
{
    public string NumeroTarjeta { get; set; }
    public decimal Saldo { get; set; }
    public int PIN { get; set; }
}

public class CargaInicialAPI
{
    public List<TarjetaCredito> CargarDesdeJSON(string rutaArchivo)
    {
        string json = File.ReadAllText(rutaArchivo);
        List<TarjetaCredito> tarjetas = JsonConvert.DeserializeObject<List<TarjetaCredito>>(json);
        return tarjetas;
    }
}

public class ConsultaSaldoAPI
{
    private LinkedList<TarjetaCredito> tarjetas = new LinkedList<TarjetaCredito>();

    public void AgregarTarjeta(TarjetaCredito tarjeta)
    {
        tarjetas.AddLast(tarjeta);
    }

    public decimal ConsultarSaldo(string numeroTarjeta)
    {
        foreach (var tarjeta in tarjetas)
        {
            if (tarjeta.NumeroTarjeta == numeroTarjeta)
            {
                return tarjeta.Saldo;
            }
        }
        return 0; // Tarjeta no encontrada
    }
}

public class RealizacionPagosAPI
{
    private Queue<TarjetaCredito> colaPagos = new Queue<TarjetaCredito>();

    public void RealizarPago(TarjetaCredito tarjeta, decimal monto)
    {
        if (tarjeta.Saldo >= monto)
        {
            tarjeta.Saldo -= monto;
            colaPagos.Enqueue(tarjeta);
        }
        else
        {
            Console.WriteLine("Saldo insuficiente para realizar el pago.");
        }
    }

    public void ProcesarColaPagos()
    {
        while (colaPagos.Count > 0)
        {
            var tarjeta = colaPagos.Dequeue();
            Console.WriteLine($"Pago realizado para la tarjeta {tarjeta.NumeroTarjeta}. Nuevo saldo: {tarjeta.Saldo}");
        }
    }
}

public class GeneracionEstadosCuentaAPI
{
    private Dictionary<string, TarjetaCredito> diccionarioTarjetas = new Dictionary<string, TarjetaCredito>();

    public void AgregarTarjeta(TarjetaCredito tarjeta)
    {
        diccionarioTarjetas.Add(tarjeta.NumeroTarjeta, tarjeta);
    }

    public void GenerarEstadoCuenta(string numeroTarjeta)
    {
        if (diccionarioTarjetas.ContainsKey(numeroTarjeta))
        {
            var tarjeta = diccionarioTarjetas[numeroTarjeta];
            Console.WriteLine($"Estado de cuenta para la tarjeta {tarjeta.NumeroTarjeta}: Saldo actual {tarjeta.Saldo}");
        }
        else
        {
            Console.WriteLine("Tarjeta no encontrada.");
        }
    }
}

public class ConsultaMovimientosAPI
{
    private Stack<string> movimientos = new Stack<string>();

    public void AgregarMovimiento(string movimiento)
    {
        movimientos.Push(movimiento);
    }

    public void MostrarUltimoMovimiento()
    {
        if (movimientos.Count > 0)
        {
            var ultimoMovimiento = movimientos.Peek();
            Console.WriteLine($"Último movimiento: {ultimoMovimiento}");
        }
        else
        {
            Console.WriteLine("No hay movimientos registrados.");
        }
    }
}

public class NotificacionesAPI
{
    private Queue<string> colaNotificaciones = new Queue<string>();

    public void EnviarNotificacion(string notificacion)
    {
        colaNotificaciones.Enqueue(notificacion);
    }

    public void ProcesarColaNotificaciones()
    {
        while (colaNotificaciones.Count > 0)
        {
            var notificacion = colaNotificaciones.Dequeue();
            Console.WriteLine($"Notificación enviada: {notificacion}");
        }
    }
}

public class CambioPINAPI
{
    private LinkedList<TarjetaCredito> tarjetas = new LinkedList<TarjetaCredito>();

    public void AgregarTarjeta(TarjetaCredito tarjeta)
    {
        tarjetas.AddLast(tarjeta);
    }

    public void CambiarPIN(string numeroTarjeta, int nuevoPIN)
    {
        foreach (var tarjeta in tarjetas)
        {
            if (tarjeta.NumeroTarjeta == numeroTarjeta)
            {
                tarjeta.PIN = nuevoPIN;
                Console.WriteLine($"PIN cambiado para la tarjeta {numeroTarjeta}. Nuevo PIN: {nuevoPIN}");
                return;
            }
        }
        Console.WriteLine("Tarjeta no encontrada.");
    }
}

public class BloqueoTemporalAPI
{
    private Dictionary<string, bool> diccionarioBloqueo = new Dictionary<string, bool>();

    public void AgregarTarjeta(string numeroTarjeta)
    {
        diccionarioBloqueo.Add(numeroTarjeta, false);
    }

    public void BloquearTarjeta(string numeroTarjeta)
    {
        if (diccionarioBloqueo.ContainsKey(numeroTarjeta))
        {
            diccionarioBloqueo[numeroTarjeta] = true;
            Console.WriteLine($"Tarjeta {numeroTarjeta} bloqueada temporalmente.");
        }
        else
        {
            Console.WriteLine("Tarjeta no encontrada.");
        }
    }

    public void DesbloquearTarjeta(string numeroTarjeta)
    {
        if (diccionarioBloqueo.ContainsKey(numeroTarjeta))
        {
            diccionarioBloqueo[numeroTarjeta] = false;
            Console.WriteLine($"Tarjeta {numeroTarjeta} desbloqueada.");
        }
        else
        {
            Console.WriteLine("Tarjeta no encontrada.");
        }
    }
}

public class SolicitudAumentoCreditoAPI
{
    private Stack<string> solicitudes = new Stack<string>();

    public void SolicitarAumento(string solicitud)
    {
        solicitudes.Push(solicitud);
    }

    public void ProcesarSolicitudes()
    {
        while (solicitudes.Count > 0)
        {
            var solicitud = solicitudes.Pop();
            Console.WriteLine($"Solicitud procesada: {solicitud}");
        }
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        // Ejemplo de uso de las APIs
        CargaInicialAPI cargaInicial = new CargaInicialAPI();
        List<TarjetaCredito> tarjetas = cargaInicial.CargarDesdeJSON("tarjetas.json");

        ConsultaSaldoAPI consultaSaldo = new ConsultaSaldoAPI();
        foreach (var tarjeta in tarjetas)
        {
            consultaSaldo.AgregarTarjeta(tarjeta);
        }
        decimal saldo = consultaSaldo.ConsultarSaldo("1234567890123456");
        Console.WriteLine($"Saldo de la tarjeta consultada: {saldo}");

        RealizacionPagosAPI realizacionPagos = new RealizacionPagosAPI();
        realizacionPagos.RealizarPago(tarjetas[0], 200);
        realizacionPagos.ProcesarColaPagos();

        GeneracionEstadosCuentaAPI generacionEstadosCuenta = new GeneracionEstadosCuentaAPI();
        foreach (var tarjeta in tarjetas)
        {
            generacionEstadosCuenta.AgregarTarjeta(tarjeta);
        }
        generacionEstadosCuenta.GenerarEstadoCuenta("9876543210987654");

        ConsultaMovimientosAPI consultaMovimientos = new ConsultaMovimientosAPI();
        consultaMovimientos.AgregarMovimiento("Compra por $50");
        consultaMovimientos.AgregarMovimiento("Retiro de efectivo por $100");
        consultaMovimientos.MostrarUltimoMovimiento();

        NotificacionesAPI notificaciones = new NotificacionesAPI();
        notificaciones.EnviarNotificacion("Alerta: Se ha realizado una compra de $200.");
        notificaciones.ProcesarColaNotificaciones();

        CambioPINAPI cambioPIN = new CambioPINAPI();
        foreach (var tarjeta in tarjetas)
        {
            cambioPIN.AgregarTarjeta(tarjeta);
        }
        cambioPIN.CambiarPIN("9876543210987654", 4321);

        BloqueoTemporalAPI bloqueoTemporal = new BloqueoTemporalAPI();
        bloqueoTemporal.AgregarTarjeta("1234567890123456");
        bloqueoTemporal.BloquearTarjeta("1234567890123456");
        bloqueoTemporal.DesbloquearTarjeta("1234567890123456");

        SolicitudAumentoCreditoAPI solicitudAumentoCredito = new SolicitudAumentoCreditoAPI();
        solicitudAumentoCredito.SolicitarAumento("Aumento de límite de $5000");
        solicitudAumentoCredito.ProcesarSolicitudes();
    }
}
