1. Descarga el proyecto:Ir al repositorio de GitHub del proyecto y hacer clic en "Code" y luego en "Download ZIP".

2. Guardar el archivo ZIP en la PC y descomprímir en una carpeta nueva.

3 Abrir Visual Estudio en la PC

4. Abrir el proyecto:ir a "Archivo" > "Abrir" > "Proyecto/Solución" en Visual Studio.

5. Navegar hasta la carpeta del proyecto descomprimido y seleccionar el archivo .sln (solución) para abrirlo.

6. Compila el proyecto:Hacer clic en "Compilar" para asegurarse de que no haya errores.

7. Revisar el código para asegurarte de que la ruta del archivo JSON de datos iniciales esté configurada correctamente.

8. Ejecutar la aplicación:
